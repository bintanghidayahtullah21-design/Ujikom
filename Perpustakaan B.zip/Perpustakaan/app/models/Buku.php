<?php
class Buku {
    private $db;

    public function __construct($db_conn) {
        $this->db = $db_conn;
    }

    public function getAllBuku() {
        $query = "SELECT * FROM buku";
        $result = mysqli_query($this->db, $query);
        return mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
}