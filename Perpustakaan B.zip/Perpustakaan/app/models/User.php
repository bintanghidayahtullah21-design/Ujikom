<?php
class UserC {
    private $db;

    public function __construct($db_conn) {
        $this->db = $db_conn;
    }

    public function cekLogin($username, $password) {
        $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
        $result = mysqli_query($this->db, $query);
        return mysqli_fetch_assoc($result);
    }
}