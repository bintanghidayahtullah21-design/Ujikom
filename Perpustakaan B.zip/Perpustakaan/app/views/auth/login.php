<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Libro</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    
    <style>
        /* Override CSS khusus Login agar di tengah layar */
        body.login-body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #4361ee 0%, #3f37c9 100%);
            padding: 20px;
        }
        .login-card {
            background: white;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .login-icon {
            font-size: 50px;
            color: #4361ee;
            margin-bottom: 20px;
        }
        .input-group {
            position: relative;
            margin-bottom: 20px;
        }
        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
        }
        .input-group input {
            padding-left: 40px; /* Memberi ruang untuk ikon */
            width: 100%;
            margin: 0; /* Reset margin input default */
        }
    </style>
</head>
<body class="login-body">

    <div class="login-card">
        <div class="login-icon">
            <i class="fas fa-book-reader"></i>
        </div>
        <h2 style="margin-bottom: 5px;">Libro</h2>
        <p style="color: #666; font-size: 0.9rem; margin-bottom: 30px;">Perpustakaan Sekolah Kita</p>

        <form action="index.php?page=proses_login" method="POST">
            
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="username" placeholder="Username" required autocomplete="off">
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <button type="submit" class="btn btn-blue" style="width: 100%; padding: 12px;">
                MASUK SEKARANG <i class="fas fa-arrow-right" style="margin-left: 5px;"></i>
            </button>
        </form>
        
        <p style="margin-top: 20px; font-size: 0.8rem; color: #888;">
            &copy; 2026 Perpustakaan Digital
        </p>
    </div>

</body>
</html>