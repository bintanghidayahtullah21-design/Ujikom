<!DOCTYPE html>
<html>
<head>
    <title>Riwayat Peminjaman</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

    <div style="margin-bottom: 20px;">
        <a href="index.php?page=user_dashboard" style="color: var(--primary);"><i class="fas fa-home"></i> Beranda</a>
    </div>

    <div class="card">
        
        <div class="header-actions">
            <div>
                <h2 style="margin: 0;">
                    <i class="fas fa-history" style="color: var(--primary);"></i> Riwayat Peminjaman
                </h2>
                <p style="color: #888; margin-top: 5px;">Daftar buku yang sedang atau pernah kamu pinjam.</p>
            </div>
        </div>

        <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

        <table>
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th>Judul Buku</th>
                    <th>Tanggal Pinjam</th>
                    <th>Tanggal Kembali</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1; 
                if (empty($bukuSaya)) {
                    echo "<tr><td colspan='6' align='center' style='padding: 30px; color: #888;'>
                            <i class='fas fa-folder-open' style='font-size: 2rem; margin-bottom: 10px;'></i><br>
                            Kamu belum pernah meminjam buku.
                          </td></tr>";
                } else {
                    foreach ($bukuSaya as $pinjam) : 
                ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td style="font-weight: 600; color: #333;">
                        <i class="fas fa-book" style="color: #ccc; margin-right: 5px;"></i>
                        <?= $pinjam['judul']; ?>
                    </td>
                    <td>
                        <i class="far fa-calendar-alt" style="color: #888;"></i> 
                        <?= date('d M Y', strtotime($pinjam['tanggal_pinjam'])); ?>
                    </td>
                    
                    <td>
                        <?php 
                        if ($pinjam['tanggal_kembali']) {
                            echo '<i class="far fa-calendar-check" style="color: var(--success);"></i> ' . date('d M Y', strtotime($pinjam['tanggal_kembali']));
                        } else {
                            echo '<span style="color: #ccc;">-</span>'; 
                        }
                        ?>
                    </td>

                    <td>
                        <?php if ($pinjam['status'] == 'dipinjam') : ?>
                            <span class="badge badge-warning">
                                <i class="fas fa-clock"></i> Sedang Dipinjam
                            </span>
                        <?php else : ?>
                            <span class="badge badge-success">
                                <i class="fas fa-check-circle"></i> Dikembalikan
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; } ?>
            </tbody>
        </table>

    </div>
</div>

</body>
</html>