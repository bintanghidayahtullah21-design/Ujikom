<!DOCTYPE html>
<html>
<head>
    <title>Libro Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    
    <div class="menu-panel">
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-book-reader" style="font-size: 1.5rem; color: var(--primary);"></i>
            <span style="font-weight: bold; font-size: 1.2rem;">Libro</span>
        </div>
        <ul>
            <li><a href="index.php?page=user_peminjaman"><i class="fas fa-history"></i> Peminjaman Saya</a></li>
            <li><a href="index.php?page=logout"><i class="fas fa-sign-out-alt"></i> Keluar</a></li>
        </ul>
    </div>

    <div class="card" style="background: linear-gradient(135deg, #4361ee 0%, #3f37c9 100%); color: white; border: none;">
        <div style="text-align: center; padding: 20px;">
            <h2 style="color: white; margin-bottom: 10px;">Halo, <?= $_SESSION['nama']; ?>! 👋</h2>
            <p style="opacity: 0.9;">Temukan buku favoritmu dan pinjam sekarang juga.</p>
            
            <form action="index.php" method="GET" style="margin-top: 20px; display: flex; justify-content: center; gap: 10px;">
                <input type="hidden" name="page" value="user_dashboard">
                <input type="text" name="cari" placeholder="Cari judul buku..." style="width: 400px; padding: 12px; border-radius: 30px; border: none; outline: none;">
                <button type="submit" class="btn" style="background: white; color: var(--primary); border-radius: 30px; padding: 0 25px;">
                    <i class="fas fa-search"></i> Cari
                </button>
            </form>
        </div>
    </div>

    <div class="card">
        <h3 style="margin-bottom: 20px;"><i class="fas fa-list"></i> Koleksi Buku Tersedia</h3>
        
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th width="10%">Sampul</th>
                        <th>Judul Buku</th>
                        <th>Pengarang</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; 
                    if(empty($daftarBuku)) {
                        echo "<tr><td colspan='6' align='center'>Buku tidak ditemukan.</td></tr>";
                    } else {
                        foreach ($daftarBuku as $b) : 
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <div style="width: 50px; height: 70px; background: linear-gradient(135deg, #4f46e5, #818cf8); color: white; display: flex; align-items: center; justify-content: center; border-radius: 6px; box-shadow: 0 2px 5px rgba(0,0,0,0.15); font-size: 24px;" title="Buku">
                                <i class="fas fa-book-open"></i>
                            </div>
                        </td>
                        <td style="font-weight: bold;"><?= $b['judul']; ?></td>
                        <td><?= $b['pengarang']; ?></td>
                        <td>
                            <?php if($b['stok'] > 0): ?>
                                <span class="badge badge-success"><?= $b['stok']; ?> Tersedia</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Habis</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($b['stok'] > 0) : ?>
                                <a href="index.php?page=user_pinjam&id=<?= $b['id']; ?>" 
                                   class="btn btn-blue btn-small"
                                   onclick="return confirm('Pinjam buku ini?')">
                                   <i class="fas fa-hand-holding-heart"></i> Pinjam
                                </a>
                            <?php else : ?>
                                <button class="btn btn-small" disabled style="background: #e5e7eb; color: #9ca3af;">Habis</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; 
                    } ?>
                </tbody>
            </table>
        </div>
    </div>


</body>
</html> 