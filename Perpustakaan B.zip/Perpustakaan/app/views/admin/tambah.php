<!DOCTYPE html>
<html>
<head>
    <title>Tambah Buku Baru</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container" style="max-width: 800px;"> <div style="margin-bottom: 20px;">
        <a href="index.php?page=admin_buku" style="color: #666; font-weight: 600;">
            <i class="fas fa-arrow-left"></i> Batal & Kembali
        </a>
    </div>

    <div class="card">
        <h2 style="margin-top: 0;">
            <i class="fas fa-plus-circle" style="color: var(--primary);"></i> Tambah Buku Baru
        </h2>
        <p style="color: #888; margin-bottom: 20px;">Masukkan detail buku baru ke dalam sistem.</p>
        
        <hr style="border: 0; border-top: 1px solid #eee; margin-bottom: 25px;">

        <form action="index.php?page=proses_tambah_buku" method="POST">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                
                <div>
                    <label>Judul Buku</label>
                    <input type="text" name="judul" placeholder="Contoh: Belajar Pemrograman Web" required>

                    <label>Pengarang</label>
                    <input type="text" name="pengarang" placeholder="Nama Penulis" required>

                    <label>Penerbit</label>
                    <input type="text" name="penerbit" placeholder="Nama Penerbit" required>
                </div>
                
                <div>
                    <label>Tahun Terbit</label>
                    <input type="number" name="tahun_terbit" placeholder="Tahun (Contoh: 2024)" required>

                    <label>Stok Awal</label>
                    <input type="number" name="stok" placeholder="Jumlah buku..." required>
                    <small style="color: #888;">*Masukkan jumlah fisik buku yang tersedia.</small>
                </div>
            </div>

            <div style="margin-top: 30px; text-align: right;">
                <button type="submit" class="btn btn-blue">
                    <i class="fas fa-save"></i> Simpan Buku
                </button>
            </div>

        </form>
    </div>
</div>

</body>
</html>