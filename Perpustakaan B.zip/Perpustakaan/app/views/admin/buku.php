<!DOCTYPE html>
<html>
<head>
    <title>Kelola Data Buku</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

    <div style="margin-bottom: 20px;">
        <a href="index.php?page=admin_dashboard" style="color: #666; font-weight: 600;">
            <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
        </a>
    </div>

    <div class="card">
        
        <div class="header-actions">
            <div>
                <h2 style="margin: 0;"><i class="fas fa-book" style="color: var(--primary);"></i> Kelola Data Buku</h2>
                <p style="color: #888; margin-top: 5px;">Daftar semua koleksi buku perpustakaan.</p>
            </div>
            
            <a href="index.php?page=view_tambah_buku" class="btn btn-blue">
                <i class="fas fa-plus-circle" style="margin-right: 8px;"></i> Tambah Buku
            </a>
        </div>
        
        <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

        <form action="index.php" method="GET" class="search-box" style="margin-bottom: 20px;">
            <input type="hidden" name="page" value="admin_buku">
            <input type="text" name="cari" placeholder="Cari Judul atau Pengarang..." style="width: 300px;">
            <button type="submit" class="btn btn-blue">
                <i class="fas fa-search"></i>
            </button>
            <a href="index.php?page=admin_buku" class="btn btn-red" title="Reset Pencarian">
                <i class="fas fa-sync-alt"></i>
            </a>
        </form>

        <table>
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th>Judul Buku</th>
                    <th>Pengarang</th>
                    <th>Penerbit</th>
                    <th>Stok</th>
                    <th width="15%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($daftarBuku as $b) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td style="font-weight: 600; color: #333;"><?= $b['judul']; ?></td>
                    <td><?= $b['pengarang']; ?></td>
                    <td><?= $b['penerbit']; ?></td>
                    <td>
                        <?php if($b['stok'] > 10): ?>
                            <span class="badge badge-success"><i class="fas fa-check-circle"></i> <?= $b['stok']; ?></span>
                        <?php elseif($b['stok'] > 0): ?>
                            <span class="badge badge-warning"><i class="fas fa-exclamation-circle"></i> <?= $b['stok']; ?></span>
                        <?php else: ?>
                            <span class="badge badge-danger"><i class="fas fa-times-circle"></i> Habis</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="index.php?page=edit_buku&id=<?= $b['id']; ?>" class="btn btn-blue btn-small" title="Edit">
                            <i class="fas fa-edit"></i>
                        </a>
                        <a href="index.php?page=hapus_buku&id=<?= $b['id']; ?>" onclick="return confirm('Yakin ingin menghapus buku ini?')" class="btn btn-red btn-small" title="Hapus">
                            <i class="fas fa-trash-alt"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    </div> </div> </body>
</html>