<!DOCTYPE html>
<html>
<head>
    <title>Libro Dashboard A</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>

<div class="container">
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <div>
            <h2 style="display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-tachometer-alt" style="color: #4361ee;"></i> Dashboard Admin
            </h2>
            <p style="color: #666; margin: 0;">Kelola perpustakaan dengan mudah.</p>
        </div>
        <a href="index.php?page=logout" class="btn btn-red">
            <i class="fas fa-sign-out-alt"></i> Keluar
        </a>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
        
        <div class="card" style="text-align: center; padding: 40px; transition: 0.3s; cursor: pointer;">
            <div style="font-size: 3rem; color: #4361ee; margin-bottom: 15px;">
                <i class="fas fa-book"></i>
            </div>
            <h3>Data Buku</h3>
            <p style="color: #888; font-size: 0.9rem;">Kelola koleksi buku, stok, dan kategori.</p>
            <a href="index.php?page=admin_buku" class="btn btn-blue">
                Kelola Buku |<i class="fas fa-arrow-right"></i>
            </a>
        </div>

        <div class="card" style="text-align: center; padding: 40px;">
            <div style="font-size: 3rem; color: #06d6a0; margin-bottom: 15px;">
                <i class="fas fa-users"></i>
            </div>
            <h3>Data Anggota</h3>
            <p style="color: #888; font-size: 0.9rem;">Kelola data siswa dan akun pengguna.</p>
            <a href="index.php?page=admin_anggota" class="btn btn-blue">
                Kelola Anggota |<i class="fas fa-arrow-right"></i>
            </a>
        </div>

        <div class="card" style="text-align: center; padding: 40px;">
            <div style="font-size: 3rem; color: #ffd166; margin-bottom: 15px;">
                <i class="fas fa-exchange-alt"></i>
            </div>
            <h3>Sirkulasi</h3>
            <p style="color: #888; font-size: 0.9rem;">Peminjaman dan pengembalian anggota.</p>
            <a href="index.php?page=admin_peminjaman" class="btn btn-blue">
                Lihat |<i class="fas fa-arrow-right"></i>
            </a>
        </div>

    </div>
</div>

</body>
</html>