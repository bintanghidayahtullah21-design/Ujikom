<!DOCTYPE html>
<html>
<head>
    <title>Kelola Data Anggota</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <div style="margin-bottom: 20px;">
        <a href="index.php?page=admin_dashboard" style="color: #666; font-weight: 600;">
            <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
        </a>
    </div>

    <div class="card">
        <div class="header-actions">
            <div>
                <h2 style="margin: 0;"><i class="fas fa-users" style="color: var(--success);"></i> Data Anggota</h2>
                <p style="color: #888; margin-top: 5px;">Kelola akun siswa dan NIS mereka.</p>
            </div>
            <a href="index.php?page=view_tambah_anggota" class="btn btn-blue">
                <i class="fas fa-user-plus"></i> Tambah Siswa Baru
            </a>
        </div>

        <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th>Nama Lengkap</th>
                        <th>NIS</th>
                        <th>Username (Login)</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($daftarAnggota as $a) : ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td style="font-weight: bold; color: #333;">
                            <i class="fas fa-user-circle" style="color: #ccc; margin-right: 5px;"></i>
                            <?= $a['nama']; ?>
                        </td>
                    <td>
                            <span class="badge" style="background: #eef2ff; color: var(--primary); font-family: monospace; font-size: 14px;">
                                <i class="fas fa-id-badge"></i> <?= !empty($a['nis']) ? $a['nis'] : '-'; ?>
                            </span>
                        </td>
                        <td style="color: #888;">
                            <?= $a['username']; ?>
                        </td>
                        <td>
                            <a href="index.php?page=view_edit_anggota&id=<?= $a['id']; ?>" class="btn btn-blue btn-small" title="Edit Data">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="index.php?page=hapus_anggota&id=<?= $a['id']; ?>" onclick="return confirm('Hapus siswa ini?')" class="btn btn-red btn-small" title="Hapus Akun">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
