<!DOCTYPE html>
<html>
<head>
    <title>Tambah Peminjaman Manual</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container" style="max-width: 600px;">
    <div style="margin-bottom: 20px;">
        <a href="index.php?page=admin_peminjaman" style="color: #666; font-weight: 600;">
            <i class="fas fa-arrow-left"></i> Batal & Kembali
        </a>
    </div>

    <div class="card">
        <h2 style="margin-top: 0;">
            <i class="fas fa-handshake" style="color: var(--primary);"></i> Form Peminjaman
        </h2>
        <p style="color: #888;">Pinjamkan buku kepada siswa secara manual (Admin).</p>
        
        <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

        <form action="index.php?page=proses_tambah_peminjaman" method="POST">
            
<label>Pilih Siswa (Peminjam)</label>
<select name="id_user" required style="width: 100%; padding: 12px; margin: 8px 0 20px 0; border-radius: 8px; border: 1px solid #d1d5db;">
    <option value="">-- Klik untuk Pilih Siswa --</option>
    <?php foreach($daftarAnggota as $siswa): ?>
        <?php if($siswa['role'] == 'user'): ?>
<option value="<?= $siswa['id']; ?>">
    <?= $siswa['nama']; ?> - [<?= $siswa['nis'] ? $siswa['nis'] : 'Belum Ada NIS'; ?>]
</option>
        <?php endif; ?>
    <?php endforeach; ?>
</select>

            <label>Pilih Buku</label>
            <select name="id_buku" required style="width: 100%; padding: 12px; margin: 8px 0 20px 0; border-radius: 8px; border: 1px solid #d1d5db;">
                <option value="">-- Klik untuk Pilih Buku --</option>
                <?php foreach($daftarBuku as $buku): ?>
                    <?php if($buku['stok'] > 0): ?>
                        <option value="<?= $buku['id']; ?>"><?= $buku['judul']; ?> (Stok: <?= $buku['stok']; ?>)</option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>

            <label>Tanggal Pinjam</label>
            <input type="date" name="tanggal_pinjam" value="<?= date('Y-m-d'); ?>" required style="width: 100%; padding: 12px; margin: 8px 0 20px 0; border-radius: 8px; border: 1px solid #d1d5db; background-color: #f3f4f6; cursor: not-allowed;" readonly>

            <div style="margin-top: 20px;">
                <button type="submit" class="btn btn-blue" style="width: 100%;">
                    <i class="fas fa-save"></i> Proses Peminjaman
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
