<!DOCTYPE html>
<html>
<head>
    <title>Tambah Siswa Baru</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container" style="max-width: 600px;">
    <div style="margin-bottom: 20px;">
        <a href="index.php?page=admin_anggota" style="color: #666; font-weight: 600;">
            <i class="fas fa-arrow-left"></i> Batal & Kembali
        </a>
    </div>

    <div class="card">
        <h2 style="margin-top: 0;">
            <i class="fas fa-user-plus" style="color: var(--primary);"></i> Tambah Siswa
        </h2>
        <p style="color: #888;">Daftarkan akun siswa baru ke sistem.</p>
        
        <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

        <form action="index.php?page=proses_tambah_anggota" method="POST">
            
            <label>Nama Lengkap</label>
            <div style="position: relative; margin-bottom: 20px;">
                <i class="fas fa-user" style="position: absolute; left: 15px; top: 15px; color: #aaa;"></i>
                <input type="text" name="nama" placeholder="Masukkan nama siswa..." required style="padding-left: 45px; width: 100%; height: 45px; border-radius: 8px; border: 1px solid #ddd;">
            </div>

            <?php 
                // Membuat angka random 5 digit sebagai NIS (Tanpa teks "NIS-")
                $nis_otomatis = rand(10000, 99999); 
            ?>
            <label>NIS</label>
            <div style="position: relative; margin-bottom: 20px;">
                <i class="fas fa-id-badge" style="position: absolute; left: 15px; top: 15px; color: #aaa;"></i>
                <input type="text" name="nis" value="<?= $nis_otomatis; ?>" readonly 
                       style="padding-left: 45px; width: 100%; height: 45px; border-radius: 8px; border: 1px solid #ddd; background-color: #f3f4f6; color: #555; cursor: not-allowed; font-weight: bold;">
            </div>

            <label>Username (Untuk Login)</label>
            <div style="position: relative; margin-bottom: 20px;">
                <i class="fas fa-at" style="position: absolute; left: 15px; top: 15px; color: #aaa;"></i>
                <input type="text" name="username" placeholder="Contoh: bintang123" required style="padding-left: 45px; width: 100%; height: 45px; border-radius: 8px; border: 1px solid #ddd;">
            </div>

            <label>Password</label>
            <div style="position: relative; margin-bottom: 20px;">
                <i class="fas fa-lock" style="position: absolute; left: 15px; top: 15px; color: #aaa;"></i>
                <input type="password" name="password" placeholder="Masukkan password..." required style="padding-left: 45px; width: 100%; height: 45px; border-radius: 8px; border: 1px solid #ddd;">
            </div>

            <div style="margin-top: 30px;">
                <button type="submit" class="btn btn-blue" style="width: 100%; height: 50px; font-size: 16px;">
                    <i class="fas fa-save"></i> Simpan Data Siswa
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
