<!DOCTYPE html>
<html>
<head>
    <title>Sirkulasi Peminjaman</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

    <div style="margin-bottom: 20px;">
        <a href="index.php?page=admin_dashboard" style="color: #666; font-weight: 600;">
            <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
        </a>
    </div>

    <div class="card">
        
        <div class="header-actions">
            <div>
                <h2 style="margin: 0;"><i class="fas fa-exchange-alt" style="color: var(--warning);"></i> Sirkulasi Peminjaman</h2>
                <p style="color: #888; margin-top: 5px;">Pantau buku yang sedang keluar dan masuk.</p>
            </div>
            
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <a href="index.php?page=view_tambah_peminjaman" class="btn btn-blue">
                    <i class="fas fa-plus"></i> Peminjaman Baru
                </a>
            </div>
        </div>

        <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

        <table>
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th>Nama Peminjam</th>
                    <th>Buku Dipinjam</th>
                    <th>Tgl Pinjam</th>
                    <th>Tgl Kembali</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($dataPinjam as $p) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $p['nama_siswa']; ?></td>
                    <td style="font-weight: 600; color: var(--primary);">
                        <i class="fas fa-book" style="color: #ccc; margin-right: 5px;"></i>
                        <?= $p['judul_buku']; ?>
                    </td>
                    <td><?= date('d M Y', strtotime($p['tanggal_pinjam'])); ?></td>
                    <td>
                        <?= $p['tanggal_kembali'] ? date('d M Y', strtotime($p['tanggal_kembali'])) : '-'; ?>
                    </td>
                    <td>
                        <?php if ($p['status'] == 'dipinjam') : ?>
                            <span class="badge badge-danger">
                                <i class="fas fa-clock"></i> Sedang Dipinjam
                            </span>
                        <?php else : ?>
                            <span class="badge badge-success">
                                <i class="fas fa-check-circle"></i> Selesai
                            </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($p['status'] == 'dipinjam') : ?>
                            <a href="index.php?page=proses_kembali&id=<?= $p['id']; ?>&id_buku=<?= $p['id_buku']; ?>" 
                               onclick="return confirm('Konfirmasi pengembalian buku ini? Stok akan bertambah.')"
                               class="btn btn-green btn-small"
                               title="Proses Pengembalian">
                               <i class="fas fa-check"></i>| Kembalikan
                            </a>
                        <?php else : ?>
                            <span style="color: #ccc; font-size: 0.9rem;">
                                <i class="fas fa-lock"></i>
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    </div>
</div>

</body>
</html>