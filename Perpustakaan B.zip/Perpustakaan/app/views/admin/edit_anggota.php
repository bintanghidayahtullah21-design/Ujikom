<!DOCTYPE html>
<html>
<head>
    <title>Edit Data Anggota</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container" style="max-width: 600px;"> 
    <div style="margin-bottom: 20px;">
        <a href="index.php?page=admin_anggota" style="color: #666; font-weight: 600;">
            <i class="fas fa-arrow-left"></i> Batal & Kembali
        </a>
    </div>

    <div class="card">
        <h2 style="margin-top: 0;">
            <i class="fas fa-user-edit" style="color: var(--primary);"></i> Edit Siswa
        </h2>
        <p style="color: #888;">Ubah data akun siswa.</p>
        
        <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

        <form action="index.php?page=proses_edit_anggota" method="POST">
            <input type="hidden" name="id" value="<?= $anggota['id']; ?>">

            <label>Nama Lengkap</label>
            <div style="position: relative;">
                <i class="fas fa-user" style="position: absolute; left: 15px; top: 22px; color: #aaa;"></i>
                <input type="text" name="nama" value="<?= $anggota['nama']; ?>" required style="padding-left: 40px;">
            </div>

            <label>Username (NIS - Tetap / Tidak bisa diubah)</label>
            <div style="position: relative;">
                <i class="fas fa-id-card" style="position: absolute; left: 15px; top: 22px; color: #aaa;"></i>
                <input type="text" name="username" value="<?= $anggota['username']; ?>" readonly style="padding-left: 40px; background-color: #f3f4f6; color: #666; cursor: not-allowed;">
            </div>

            <label>Password</label>
            <div style="position: relative;">
                <i class="fas fa-lock" style="position: absolute; left: 15px; top: 22px; color: #aaa;"></i>
                <input type="text" name="password" value="<?= $anggota['password']; ?>" required style="padding-left: 40px;">
            </div>

            <div style="margin-top: 30px;">
                <button type="submit" class="btn btn-blue" style="width: 100%;">
                    <i class="fas fa-save"></i> Update Data Siswa
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
