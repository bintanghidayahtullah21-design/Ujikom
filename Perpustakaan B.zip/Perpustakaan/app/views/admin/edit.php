<!DOCTYPE html>
<html>
<head>
    <title>Edit Data Buku</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container" style="max-width: 800px;"> <div style="margin-bottom: 20px;">
        <a href="index.php?page=admin_buku" style="color: #666; font-weight: 600;">
            <i class="fas fa-arrow-left"></i> Batal & Kembali
        </a>
    </div>

    <div class="card">
        <h2 style="margin-top: 0;">
            <i class="fas fa-edit" style="color: var(--warning);"></i> Edit Buku
        </h2>
        <p style="color: #888; margin-bottom: 20px;">Perbarui informasi buku di bawah ini.</p>
        
        <hr style="border: 0; border-top: 1px solid #eee; margin-bottom: 25px;">

        <form action="index.php?page=proses_edit_buku" method="POST">
            <input type="hidden" name="id" value="<?= $buku['id']; ?>">

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div>
                    <label>Judul Buku</label>
                    <input type="text" name="judul" value="<?= $buku['judul']; ?>" required>

                    <label>Pengarang</label>
                    <input type="text" name="pengarang" value="<?= $buku['pengarang']; ?>" required>

                    <label>Penerbit</label>
                    <input type="text" name="penerbit" value="<?= $buku['penerbit']; ?>" required>
                </div>
                
                <div>
                    <label>Tahun Terbit</label>
                    <input type="number" name="tahun_terbit" value="<?= $buku['tahun_terbit']; ?>" required>

                    <label>Stok Buku</label>
                    <input type="number" name="stok" value="<?= $buku['stok']; ?>" required>
                    <small style="color: #888;">*Pastikan stok sesuai dengan fisik buku.</small>
                </div>
            </div>

            <div style="margin-top: 30px; text-align: right;">
                <button type="submit" class="btn btn-blue">
                    <i class="fas fa-save"></i> Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html>