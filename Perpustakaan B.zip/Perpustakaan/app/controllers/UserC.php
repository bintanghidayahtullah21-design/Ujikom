<?php
class UserC {
    private $db;

    public function __construct($db_koneksi) {
        $this->db = $db_koneksi;
        
        // Cek Login User
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
            header('Location: index.php?page=login');
            exit;
        }
    }

  // Update fungsi ini di UserC.php
    public function dashboard() {
        // Logika Pencarian
        if (isset($_GET['cari'])) {
            $keyword = $_GET['cari'];
            $query = "SELECT * FROM buku WHERE judul LIKE '%$keyword%' OR pengarang LIKE '%$keyword%' ORDER BY judul ASC";
        } else {
            $query = "SELECT * FROM buku ORDER BY judul ASC";
        }

        $result = mysqli_query($this->db, $query);
        $daftarBuku = mysqli_fetch_all($result, MYSQLI_ASSOC);
        
        require_once '../app/views/user/dashboard.php';
    }

    // Di dalam fungsi pinjamBuku() di UserC.php

public function pinjamBuku() {
        // 1. Cek Login (Pastikan Session ID ada)
        if (!isset($_SESSION['id'])) {
            echo "<script>alert('Sesi habis! Silakan login lagi.'); window.location='index.php?page=login';</script>";
            exit;
        }

        // 2. Ambil Data
        $id_buku = $_GET['id']; 
        $id_user = $_SESSION['id'];
        $tanggal = date('Y-m-d'); 

        // 3. Cek Stok Buku
        $cekStok = mysqli_query($this->db, "SELECT stok FROM buku WHERE id = '$id_buku'");
        $dataBuku = mysqli_fetch_assoc($cekStok);

        if ($dataBuku && $dataBuku['stok'] > 0) {
            // A. Kurangi Stok
            $updateStok = mysqli_query($this->db, "UPDATE buku SET stok = stok - 1 WHERE id = '$id_buku'");

            // B. Catat Peminjaman
            $insertPinjam = mysqli_query($this->db, "INSERT INTO peminjaman (id_user, id_buku, tanggal_pinjam, status) VALUES ('$id_user', '$id_buku', '$tanggal', 'dipinjam')");
            
            // C. Cek Sukses
            if ($updateStok && $insertPinjam) {
                echo "<script>
                        alert('Berhasil Meminjam Buku!');
                        window.location.href = 'index.php?page=user_dashboard';
                      </script>";
                exit; // PENTING: Hentikan script agar tidak lanjut ke kode lain
            } else {
                // Jika Gagal Database
                echo "Gagal menyimpan: " . mysqli_error($this->db);
            }
        } else {
            // Jika Stok Habis
            echo "<script>
                    alert('Maaf, Stok buku ini habis!');
                    window.location.href = 'index.php?page=user_dashboard';
                  </script>";
            exit;
        }
    }

    // Fungsi Baru: Menampilkan Halaman Peminjaman Saya
    public function viewPeminjaman() {
        $id_user = $_SESSION['id']; 

        // Query JOIN untuk mengambil data peminjaman + judul buku
        $query = "SELECT peminjaman.*, buku.judul 
                  FROM peminjaman 
                  JOIN buku ON peminjaman.id_buku = buku.id 
                  WHERE peminjaman.id_user = '$id_user'";
        
        $result = mysqli_query($this->db, $query);
        $bukuSaya = mysqli_fetch_all($result, MYSQLI_ASSOC);
        
        // Panggil View yang baru kita buat tadi
        require_once '../app/views/user/peminjaman.php';
    }

}
