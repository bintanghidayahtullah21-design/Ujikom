<?php
class AdminC {
    private $db;

    public function __construct($db_koneksi) {
        $this->db = $db_koneksi;
        
        // Cek Login Admin
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            header('Location: index.php?page=login');
            exit;
        }
    }

    // --- 1. DASHBOARD UTAMA (MENU) ---
    public function dashboard() {
        require_once '../app/views/admin/dashboard.php';
    }

    // --- 2. FITUR KELOLA BUKU ---
    public function viewBuku() {
        if (isset($_GET['cari'])) {
            $keyword = $_GET['cari'];
            $query = "SELECT * FROM buku WHERE judul LIKE '%$keyword%' OR pengarang LIKE '%$keyword%' ORDER BY id DESC";
        } else {
            $query = "SELECT * FROM buku ORDER BY id DESC";
        }

        $result = mysqli_query($this->db, $query);
        $daftarBuku = mysqli_fetch_all($result, MYSQLI_ASSOC);
        
        require_once '../app/views/admin/buku.php';
    }

    public function viewTambahBuku() {
        require_once '../app/views/admin/tambah.php';
    }

    public function tambahBuku() {
        $judul = $_POST['judul'];
        $pengarang = $_POST['pengarang'];
        $penerbit = $_POST['penerbit'];
        $tahun = $_POST['tahun_terbit'];
        $stok = $_POST['stok'];

        $query = "INSERT INTO buku (judul, pengarang, penerbit, tahun_terbit, stok) 
                  VALUES ('$judul', '$pengarang', '$penerbit', '$tahun', '$stok')";
        
        if (mysqli_query($this->db, $query)) {
            echo "<script>alert('Buku berhasil ditambah!'); window.location='index.php?page=admin_buku';</script>";
        } else {
            echo "Error: " . mysqli_error($this->db);
        }
    }

    public function hapusBuku() {
        $id = $_GET['id'];
        $query = "DELETE FROM buku WHERE id = '$id'";
        
        if (mysqli_query($this->db, $query)) {
            echo "<script>alert('Buku berhasil dihapus!'); window.location='index.php?page=admin_buku';</script>";
        }
    }

    public function viewEditBuku() {
        $id = $_GET['id'];
        $query = "SELECT * FROM buku WHERE id = '$id'";
        $result = mysqli_query($this->db, $query);
        $buku = mysqli_fetch_assoc($result);
        
        require_once '../app/views/admin/edit.php';
    }

    public function editBuku() {
        $id = $_POST['id'];
        $judul = $_POST['judul'];
        $pengarang = $_POST['pengarang'];
        $penerbit = $_POST['penerbit'];
        $tahun = $_POST['tahun_terbit'];
        $stok = $_POST['stok'];

        $query = "UPDATE buku SET 
                  judul = '$judul', 
                  pengarang = '$pengarang', 
                  penerbit = '$penerbit', 
                  tahun_terbit = '$tahun',
                  stok = '$stok' 
                  WHERE id = '$id'";
        
        if (mysqli_query($this->db, $query)) {
            echo "<script>alert('Buku berhasil diupdate!'); window.location='index.php?page=admin_buku';</script>";
        } else {
            die("Gagal Update: " . mysqli_error($this->db));
        }
    }

    // --- 3. FITUR KELOLA PEMINJAMAN ---
    public function viewPeminjaman() {
        $query = "SELECT peminjaman.*, users.nama AS nama_siswa, buku.judul AS judul_buku 
                  FROM peminjaman 
                  JOIN users ON peminjaman.id_user = users.id 
                  JOIN buku ON peminjaman.id_buku = buku.id 
                  ORDER BY peminjaman.id DESC";
        
        $result = mysqli_query($this->db, $query);
        $dataPinjam = mysqli_fetch_all($result, MYSQLI_ASSOC);

        require_once '../app/views/admin/peminjaman.php';
    }

    public function kembalikanBuku() {
        $id_peminjaman = $_GET['id'];
        $id_buku = $_GET['id_buku'];
        $tanggal_kembali = date('Y-m-d');

        $updateStatus = "UPDATE peminjaman SET 
                         status = 'dikembalikan', 
                         tanggal_kembali = '$tanggal_kembali' 
                         WHERE id = '$id_peminjaman'";

        $updateStok = "UPDATE buku SET stok = stok + 1 WHERE id = '$id_buku'";

        if (mysqli_query($this->db, $updateStatus) && mysqli_query($this->db, $updateStok)) {
            echo "<script>alert('Buku berhasil dikembalikan!'); window.location='index.php?page=admin_peminjaman';</script>";
        } else {
            echo "Gagal: " . mysqli_error($this->db);
        }
    }

    public function viewTambahPeminjaman() {
        $daftarAnggota = mysqli_query($this->db, "SELECT * FROM users WHERE role = 'user'");
        $daftarBuku = mysqli_query($this->db, "SELECT * FROM buku WHERE stok > 0");
        
        require_once '../app/views/admin/tambah_peminjaman.php';
    }

    public function prosesTambahPeminjaman() {
        $id_user = $_POST['id_user'];
        $id_buku = $_POST['id_buku'];
        $tanggal_pinjam = $_POST['tanggal_pinjam'];
        
        if(empty($id_user) || empty($id_buku)) {
            echo "<script>alert('Siswa dan Buku harus dipilih!'); window.location='index.php?page=view_tambah_peminjaman';</script>";
            exit;
        }

        $query_pinjam = "INSERT INTO peminjaman (id_user, id_buku, tanggal_pinjam, status) 
                         VALUES ('$id_user', '$id_buku', '$tanggal_pinjam', 'dipinjam')";
        
        if (mysqli_query($this->db, $query_pinjam)) {
            mysqli_query($this->db, "UPDATE buku SET stok = stok - 1 WHERE id = '$id_buku'");
            echo "<script>alert('Peminjaman berhasil dicatat!'); window.location='index.php?page=admin_peminjaman';</script>";
        } else {
            echo "<script>alert('Gagal memproses peminjaman!'); window.location='index.php?page=view_tambah_peminjaman';</script>";
        }
    }

    // --- 4. FITUR KELOLA ANGGOTA (SISWA) ---
    public function viewAnggota() {
        $query = "SELECT * FROM users WHERE role = 'user' ORDER BY nama ASC";
        $result = mysqli_query($this->db, $query);
        $daftarAnggota = mysqli_fetch_all($result, MYSQLI_ASSOC);
        
        require_once '../app/views/admin/anggota.php';
    }

    public function viewTambahAnggota() {
        require_once '../app/views/admin/tambah_anggota.php';
    }

    // FUNGSI INI SUDAH DIPERBARUI UNTUK MENYIMPAN NIS
    public function tambahAnggota() {
        $nama = mysqli_real_escape_string($this->db, $_POST['nama']);
        $nis = mysqli_real_escape_string($this->db, $_POST['nis']); 
        $username = mysqli_real_escape_string($this->db, $_POST['username']);
        $password = mysqli_real_escape_string($this->db, $_POST['password']);
        $role = 'user';

        $cek = mysqli_query($this->db, "SELECT * FROM users WHERE username = '$username'");
        if (mysqli_num_rows($cek) > 0) {
            echo "<script>alert('Username sudah dipakai! Ganti yang lain.'); window.history.back();</script>";
            return;
        }

        $query = "INSERT INTO users (nama, nis, username, password, role) 
                  VALUES ('$nama', '$nis', '$username', '$password', '$role')";
        
        if (mysqli_query($this->db, $query)) {
            echo "<script>alert('Siswa berhasil ditambahkan!'); window.location='index.php?page=admin_anggota';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan siswa!'); window.location='index.php?page=view_tambah_anggota';</script>";
        }
    }

    public function viewEditAnggota() {
        $id = $_GET['id'];
        $query = "SELECT * FROM users WHERE id = '$id'";
        $result = mysqli_query($this->db, $query);
        $anggota = mysqli_fetch_assoc($result);
        
        require_once '../app/views/admin/edit_anggota.php';
    }

    // FUNGSI INI SUDAH DIPERBARUI (NIS TIDAK IKUT DIUBAH / FIXED)
    public function editAnggota() {
        $id = $_POST['id'];
        $nama = mysqli_real_escape_string($this->db, $_POST['nama']);
        $username = mysqli_real_escape_string($this->db, $_POST['username']);
        $password = mysqli_real_escape_string($this->db, $_POST['password']);

        $query = "UPDATE users SET 
                  nama = '$nama', 
                  username = '$username', 
                  password = '$password' 
                  WHERE id = '$id'";
        
        if (mysqli_query($this->db, $query)) {
            echo "<script>alert('Data siswa berhasil diupdate!'); window.location='index.php?page=admin_anggota';</script>";
        } else {
             echo "<script>alert('Gagal mengupdate data!'); window.location='index.php?page=admin_anggota';</script>";
        }
    }

    public function hapusAnggota() {
        $id = $_GET['id'];
        $query = "DELETE FROM users WHERE id = '$id'";
        
        if (mysqli_query($this->db, $query)) {
            echo "<script>alert('Siswa berhasil dihapus!'); window.location='index.php?page=admin_anggota';</script>";
        }
    }
}
?>
