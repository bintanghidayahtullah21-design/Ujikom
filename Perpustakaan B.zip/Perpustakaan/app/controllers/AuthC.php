<?php
class AuthC {
    private $db;

    public function __construct($db_koneksi) {
        $this->db = $db_koneksi;
    }

    // PERBAIKAN: Mengganti nama fungsi dari 'index' menjadi 'login'
    public function login() {
        require_once '../app/views/auth/login.php';
    }

    public function prosesLogin() {
        // 1. Ambil Input
        $username = $_POST['username'];
        $password = $_POST['password'];

        // 2. Bersihkan Input (Mencegah Error SQL Syntax)
        $username = mysqli_real_escape_string($this->db, $username);
        $password = mysqli_real_escape_string($this->db, $password);

        // 3. Query Cek User
        $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
        $result = mysqli_query($this->db, $query);

        if (!$result) {
            die("Error SQL: " . mysqli_error($this->db));
        }

        $user = mysqli_fetch_assoc($result);

        if ($user) {
            // Set Session
            $_SESSION['role'] = $user['role'];
            $_SESSION['nama'] = $user['nama'];
            $_SESSION['id'] = $user['id'];

            // Redirect sesuai role
            if ($user['role'] == 'admin') {
                header("Location: index.php?page=admin_dashboard");
            } else {
                header("Location: index.php?page=user_dashboard");
            }
            exit;
        } else {
            echo "<script>alert('Username atau Password salah!'); window.location='index.php?page=login';</script>";
        }
    }

    public function logout() {
        session_destroy();
        // Redirect ke halaman login setelah logout
        echo "<script>alert('Anda telah logout!'); window.location='index.php?page=login';</script>";
        exit;
    }
}