<?php
session_start();

// Menampilkan error agar mudah diperbaiki jika ada masalah
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Memanggil file pendukung
require_once '../app/config/database.php';
require_once '../app/controllers/AuthC.php';
require_once '../app/controllers/AdminC.php';
require_once '../app/controllers/UserC.php';

// Menentukan halaman yang sedang dibuka
$page = isset($_GET['page']) ? $_GET['page'] : 'login';

// Inisialisasi Auth Controller (Kembali menggunakan $conn)
$auth = new AuthC($conn); 

switch ($page) {

    // --- AUTHENTICATION ---
    case 'login':
        $auth->login();
        break;
    case 'proses_login':
        $auth->prosesLogin();
        break;
    case 'register':
        $auth->register();
        break;
    case 'proses_register':
        $auth->prosesRegister();
        break;
    case 'logout':
        $auth->logout();
        break;

    // --- ADMIN AREA (BUKU) ---
    case 'admin_dashboard':
        $admin = new AdminC($conn); 
        $admin->dashboard();
        break;
    case 'admin_buku':
        $admin = new AdminC($conn);
        $admin->viewBuku();
        break;
    case 'view_tambah_buku':
        $admin = new AdminC($conn);
        $admin->viewTambahBuku();
        break;
    case 'proses_tambah_buku':
        $admin = new AdminC($conn);
        $admin->tambahBuku();
        break;
    case 'edit_buku':
        $admin = new AdminC($conn);
        $admin->viewEditBuku(); 
        break;
    case 'proses_edit_buku':
        $admin = new AdminC($conn);
        $admin->editBuku();
        break;
    case 'hapus_buku':
        $admin = new AdminC($conn);
        $admin->hapusBuku();
        break;

    // --- ADMIN AREA (ANGGOTA) ---
    case 'admin_anggota':
        $admin = new AdminC($conn);
        $admin->viewAnggota();
        break;
    case 'view_tambah_anggota':
        $admin = new AdminC($conn);
        $admin->viewTambahAnggota();
        break;
    case 'proses_tambah_anggota':
        $admin = new AdminC($conn);
        $admin->tambahAnggota();
        break;
    case 'view_edit_anggota':
        $admin = new AdminC($conn);
        $admin->viewEditAnggota();
        break;
    case 'proses_edit_anggota':
        $admin = new AdminC($conn);
        $admin->editAnggota();
        break;
    case 'hapus_anggota':
        $admin = new AdminC($conn);
        $admin->hapusAnggota();
        break;

    // --- ADMIN AREA (PEMINJAMAN) ---
    case 'admin_peminjaman':
        $admin = new AdminC($conn);
        $admin->viewPeminjaman();
        break;
    case 'proses_kembali':
        $admin = new AdminC($conn);
        $admin->kembalikanBuku();
        break;
        
    // INI RUTE BARU YANG DITAMBAHKAN AGAR TIDAK KE LOGIN
    case 'view_tambah_peminjaman':
        $admin = new AdminC($conn);
        $admin->viewTambahPeminjaman();
        break;
    case 'proses_tambah_peminjaman':
        $admin = new AdminC($conn);
        $admin->prosesTambahPeminjaman();
        break;

    // --- USER AREA (SISWA) ---
    case 'user_dashboard':
        $user = new UserC($conn); 
        $user->dashboard();
        break;
    case 'user_pinjam':
        $user = new UserC($conn); 
        $user->pinjamBuku();
        break;
    case 'user_peminjaman':
        $user = new UserC($conn);
        $user->viewPeminjaman();
        break;

    // --- DEFAULT PAGE ---
    default:
        $auth->login();
        break;
}
